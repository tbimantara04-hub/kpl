# XSS Forum Demo (PHP + MySQL) — *Untuk Edukasi Lokal Saja*

> **Peringatan:** Proyek ini **sengaja rentan XSS** untuk simulasi/edukasi. Jalankan **hanya di localhost** atau jaringan lab yang terisolasi. **Jangan** deploy ke internet/produksi.

## Isi
- `db.sql` — skema & seed database
- `config.php` — koneksi DB (PDO)
- `index.php` — daftar post + *reflected XSS* via parameter `q`
- `post.php` — detail post + komentar (*stored XSS*)
- `new_post.php` — membuat post baru
- `assets/demo.js` — *DOM-based XSS* via `location.hash`
- `assets/style.css` — gaya minimal

## Setup Cepat (Laragon/XAMPP/WAMP)
1) Buat folder di webroot, mis. **Laragon**: `C:\laragon\www\xss_forum_demo_php` (atau ekstrak ZIP ini ke sana).
2) Buat DB:
   - Buka **phpMyAdmin** → jalankan isi `db.sql`, atau
   - MySQL CLI: `mysql -u root -p < db.sql`
3) Edit `config.php` jika user/password DB berbeda (default root tanpa password umum di Laragon).
4) Akses: `http://localhost/xss_forum_demo_php/`

---

## Playbook Demo XSS

### 1) Reflected XSS
- Buka:
  ```
  /index.php?q=<script>alert(1)</script>
  ```
- Perhatikan teks "Hasil untuk: ..." mengeksekusi script karena *unescaped output*.
- Variasi aman-untuk-demo:
  ```
  /index.php?q=<img src=x onerror=alert('reflected')>
  ```

### 2) Stored XSS (di komentar atau judul/isi post)
- Buka `/new_post.php` → buat post baru dengan judul **bebas**, lalu pada **Isi Post** masukkan:
  ```
  <img src=x onerror=alert('stored')>
  ```
- Simpan, lalu buka post tsb (atau tulis payload di kolom **Komentar** di halaman post).
- Saat halaman dirender, payload jalan untuk siapa pun yang membuka.

### 3) DOM-based XSS (client-side sink)
- Di halaman beranda, tambahkan fragmen/hash pada URL:
  ```
  /index.php#<svg onload=alert('dom')>
  ```
- Area "Live preview" mengambil `location.hash` dan memasukkannya ke `innerHTML` → script jalan.

> **Catatan Demo Cookie (opsional):** Aplikasi ini men-set cookie `demo_token` **tanpa** HttpOnly untuk demonstrasi risiko. Dengan XSS, `document.cookie` bisa terbaca.
> Contoh payload (opsional & lokal saja): `alert(document.cookie)`

---

## Catatan Keamanan & Etika
- Gunakan hanya di lingkungan **lokal**/lab. Jangan isi payload yang mengekfiltrasi data ke server eksternal.
- Untuk *hardening* setelah demo, lihat komentar `// FIX:` di file PHP/JS sebagai panduan mitigasi: gunakan *contextual escaping*, sanitasi (DOMPurify), CSP + nonce, dan Trusted Types.

Semoga demonstrasinya lancar! 💥
