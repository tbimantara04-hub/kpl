<?php require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = $_POST['title'] ?? '';
  $body  = $_POST['body'] ?? '';
  // VULN (sengaja): simpan tanpa sanitasi
  $ins = $pdo->prepare("INSERT INTO posts (title, body) VALUES (?, ?)");
  $ins->execute([$title, $body]);
  header("Location: index.php");
  exit;
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Buat Post — Forum Demo XSS</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <div class="desktop">
    <div class="window">

      <?php $current = basename($_SERVER['SCRIPT_NAME']); ?>
      <div class="menubar">
        <div class="tabs" role="navigation" aria-label="Utama">
          <a href="index.php"
             class="<?php echo $current==='index.php' ? 'active' : '' ?>"
             aria-current="<?php echo $current==='index.php' ? 'page' : 'false' ?>">
            Beranda
          </a>
          <a href="new_post.php"
             class="<?php echo $current==='new_post.php' ? 'active' : '' ?>"
             aria-current="<?php echo $current==='new_post.php' ? 'page' : 'false' ?>">
            Buat Post
          </a>
          <a href="https://localhost/" target="_blank" rel="noopener">Localhost</a>
        </div>
        <div class="dots" aria-hidden="true">
          <span class="dot dot1"></span>
          <span class="dot dot2"></span>
          <span class="dot dot3"></span>
        </div>
      </div>

      <div class="titlebar">
        <div class="bars" aria-hidden="true"></div>
        <h1>Webflow Weekly</h1>
        <div class="bars" aria-hidden="true"></div>
      </div>

      <div class="side-tabs" aria-hidden="true">
        <div class="tab left">HD</div>
        <div class="tab right">Me</div>
        <div class="tab right">nts</div>
        <div class="tab right">flow</div>
      </div>

      <div class="viewport">
        <div class="inner">
          <div class="header">
            <div class="brand">🔥 Forum Demo XSS <span class="badge mono">EDU</span></div>
          </div>

          <div class="card">
            <h2 style="margin-top:0">Buat Post</h2>
            <form method="post">
              <label for="title">Judul</label>
              <input id="title" name="title" placeholder="mis. Pengumuman, Tanya Jawab, dsb.">

              <div style="height:10px"></div>

              <label for="body">Isi Post</label>
              <textarea id="body" name="body" rows="8" placeholder="Anda dapat menaruh payload XSS di sini untuk simulasi."></textarea>

              <div style="margin-top:10px; display:flex; align-items:center; gap:12px; flex-wrap:wrap">
                <button type="submit">Simpan</button>
                <span class="meta">Contoh payload (stored): <code class="mono">&lt;img src=x onerror=alert('stored')&gt;</code></span>
              </div>
            </form>
          </div>

          <footer>Demo XSS lokal • Gunakan hanya untuk edukasi • © <?php echo date('Y'); ?></footer>
        </div>
      </div>

      <div class="statusbar">
        <div><span id="arrowBack" class="arrow left" role="button" tabindex="0" aria-label="Kembali"></span></div>
        <div><span class="badge-mini">Made for EDU (PHP)</span> <span id="arrowFwd" class="arrow right" role="button" tabindex="0" aria-label="Maju"></span></div>
      </div>

    </div>
  </div>
  <script src="assets/demo.js"></script>
</body>
</html>
