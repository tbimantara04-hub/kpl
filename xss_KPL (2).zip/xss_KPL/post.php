<?php require __DIR__ . '/config.php';

// Ambil post
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$id]);
$post = $stmt->fetch();
if (!$post) {
  http_response_code(404);
  echo "Post tidak ditemukan";
  exit;
}

// Tambah komentar (POST) — fokus XSS, bukan CSRF
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $author = $_POST['author'] ?? 'anonim';
  $body   = $_POST['body'] ?? '';
  // VULN: konten disimpan apa adanya
  $ins = $pdo->prepare("INSERT INTO comments (post_id, author, body) VALUES (?, ?, ?)");
  $ins->execute([$id, $author, $body]);
  header("Location: post.php?id=$id");
  exit;
}

// Ambil komentar
$cstmt = $pdo->prepare("SELECT * FROM comments WHERE post_id = ? ORDER BY created_at ASC");
$cstmt->execute([$id]);
$comments = $cstmt->fetchAll();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo $post['title']; ?> — Forum Demo XSS</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <div class="desktop">
    <div class="window">

      <?php $current = basename($_SERVER['SCRIPT_NAME']); ?>
      <div class="menubar">
        <div class="tabs" role="navigation" aria-label="Utama">
          <a href="index.php"
             class="active"
             aria-current="page">
            Beranda
          </a>
          <a href="new_post.php">Buat Post</a>
          <a href="https://localhost/" target="_blank" rel="noopener">Localhost</a>
        </div>
        <div class="dots" aria-hidden="true">
          <span class="dot dot1"></span>
          <span class="dot dot2"></span>
          <span class="dot dot3"></span>
        </div>
      </div>

      <div class="titlebar">
        <div class="bars" aria-hidden="true"></div>
        <h1>Webflow Weekly</h1>
        <div class="bars" aria-hidden="true"></div>
      </div>

      <div class="side-tabs" aria-hidden="true">
        <div class="tab left">HD</div>
        <div class="tab right">Me</div>
        <div class="tab right">nts</div>
        <div class="tab right">flow</div>
      </div>

      <div class="viewport">
        <div class="inner">
          <div class="header">
            <div class="brand">🔥 Forum Demo XSS <span class="badge mono">EDU</span></div>
          </div>

          <div class="card">
            <!-- VULN: judul & isi tanpa escaping -->
            <h2 style="margin-top:0"><?php echo $post['title']; ?></h2>
            <div class="meta">Diposting: <?php echo $post['created_at']; ?></div>
            <hr>
            <div><?php echo $post['body']; ?></div>
          </div>

          <div class="card">
            <h3>Komentar (<?php echo count($comments); ?>)</h3>
            <?php if (!$comments): ?>
              <div class="meta">Belum ada komentar.</div>
            <?php else: ?>
              <?php foreach ($comments as $c): ?>
                <div class="card">
                  <div class="meta">Oleh: <?php echo $c['author']; ?> • <?php echo $c['created_at']; ?></div>
                  <!-- VULN: komentar dicetak tanpa escaping -->
                  <div><?php echo $c['body']; ?></div>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>

          <div class="card">
            <h3>Tambah Komentar</h3>
            <form method="post">
              <label for="author">Nama</label>
              <input id="author" name="author" placeholder="nama (opsional)" value="anonim">

              <div style="height:10px"></div>

              <label for="body">Komentar</label>
              <textarea id="body" name="body" rows="5" placeholder="ketik komentar di sini..."></textarea>

              <div style="margin-top:10px; display:flex; align-items:center; gap:12px; flex-wrap:wrap">
                <button type="submit">Kirim</button>
                <span class="meta">Contoh payload (stored): <code class="mono">&lt;img src=x onerror=alert('stored')&gt;</code></span>
              </div>
            </form>
          </div>

          <footer>Demo XSS lokal • Gunakan hanya untuk edukasi • © <?php echo date('Y'); ?></footer>
        </div>
      </div>

      <div class="statusbar">
        <div><span id="arrowBack" class="arrow left" role="button" tabindex="0" aria-label="Kembali"></span></div>
        <div><span class="badge-mini">Made for EDU (PHP)</span> <span id="arrowFwd" class="arrow right" role="button" tabindex="0" aria-label="Maju"></span></div>
      </div>

    </div>
  </div>
  <script src="assets/demo.js"></script>
</body>
</html>
