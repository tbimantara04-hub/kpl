<?php
// ======== Config & DB (VULN DEMO ONLY) ========
// Sesuaikan kredensial MySQL Anda.
$DB_HOST = '127.0.0.1';
$DB_NAME = 'xss_forum_demo';
$DB_USER = 'root';
$DB_PASS = '';

// Non-HttpOnly cookie untuk demo risiko pembacaan cookie via XSS (JANGAN di produksi)
if (!isset($_COOKIE['demo_token'])) {
  $token = bin2hex(random_bytes(8));
  // tidak set HttpOnly: parameter ke-7 (httponly) di setcookie default-nya false jika pakai signature lama.
  setcookie('demo_token', $token, 0, '/'); // FIX: set httponly=true dan secure=true di produksi
}

$dsn = "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4";
$options = [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];
try {
  $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
} catch (Exception $e) {
  http_response_code(500);
  echo "DB error: " . htmlspecialchars($e->getMessage());
  exit;
}

// Start session (default PHP biasanya HttpOnly=On utk session cookie, tapi kita tidak andalkan itu dalam demo)
session_start();
?>
