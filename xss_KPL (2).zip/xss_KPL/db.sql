-- Drop & create for a clean demo
DROP DATABASE IF EXISTS xss_forum_demo;
CREATE DATABASE xss_forum_demo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE xss_forum_demo;

CREATE TABLE posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  post_id INT NOT NULL,
  author VARCHAR(100) NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed posts (aman)
INSERT INTO posts (title, body) VALUES
('Selamat datang di Forum', 'Ini forum demo untuk simulasi XSS. Silakan buat post/komentar untuk uji coba.'),
('Tips Demo', 'Coba parameter q di index.php untuk reflected XSS. Tambahkan komentar/post dengan payload untuk stored XSS.');
