// Demo DOM XSS (sengaja): render fragment sebagai HTML
function renderFragment() {
  const el = document.getElementById('live-fragment');
  if (!el) return;
  const hash = decodeURIComponent(location.hash.slice(1));
  // VULN: innerHTML (sengaja untuk demo)
  el.innerHTML = hash || '<span style="opacity:.6">#(kosong)</span>';
}
window.addEventListener('hashchange', renderFragment);
document.addEventListener('DOMContentLoaded', renderFragment);

// Tombol back/forward di statusbar
document.addEventListener('DOMContentLoaded', () => {
  const back = document.getElementById('arrowBack');
  const fwd  = document.getElementById('arrowFwd');
  back && back.addEventListener('click', () => history.back());
  fwd && fwd.addEventListener('click', () => history.forward());
  // keyboard
  [back,fwd].forEach(btn=>{
    if(!btn) return;
    btn.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter' || e.key === ' ') { e.preventDefault(); btn.click(); }
    });
  });
});
